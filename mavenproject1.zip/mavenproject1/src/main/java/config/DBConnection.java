/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author 61405045
 */
public class DBConnection {

    private static final String URL =
        "jdbc:sqlserver://localhost;databaseName=CSM;encrypt=true;trustServerCertificate=true";

    private static final String USER = "sa";
    private static final String PASSWORD = "Padmin123";

    public static Connection getConnection() {

        Connection conn = null;

        try {

            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            conn = DriverManager.getConnection(
                    URL,
                    USER,
                    PASSWORD);

            System.out.println("Koneksi berhasil");

        } catch (Exception e) {

            System.out.println("Koneksi gagal");
            e.printStackTrace();

        }

        return conn;
    }
}