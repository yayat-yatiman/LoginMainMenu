<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Dashboard Admin</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">

</head>
<body>

<div class="wrapper">

    <!-- SIDEBAR -->
    <div class="sidebar">

        <div class="logo">
            <i class="bi bi-shield-check fs-1"></i>
            <h3>My System</h3>
        </div>

        <div class="menu-title">MAIN MENU</div>

        <ul>
            <li>
                <a href="dashboard.jsp">
                    <i class="bi bi-speedometer2"></i>
                    Dashboard
                </a>
            </li>

            <li>
                <a href="employee-list.jsp">
                    <i class="bi bi-people"></i>
                    Karyawan
                </a>
            </li>

            <li>
                <a href="product-list.jsp">
                    <i class="bi bi-box-seam"></i>
                    Produk
                </a>
            </li>

            <li>
                <a href="sales-list.jsp">
                    <i class="bi bi-cart"></i>
                    Penjualan
                </a>
            </li>

            <li>
                <a href="report.jsp">
                    <i class="bi bi-file-earmark-bar-graph"></i>
                    Laporan
                </a>
            </li>
        </ul>

    </div>

    <!-- MAIN -->
    <div class="main">

        <!-- TOPBAR -->
        <div class="topbar">

            <h4>Dashboard Admin</h4>

            <a href="logout.jsp" class="logout-btn">
                <i class="bi bi-box-arrow-right"></i>
                Logout
            </a>

        </div>

        <!-- CONTENT -->
        <div class="content">

            <div class="page-header">
                <h2>Dashboard</h2>
            </div>

            <div class="cards">

                <div class="card">
                    <h1>150</h1>
                    <p>Total Karyawan</p>
                </div>

                <div class="card">
                    <h1>320</h1>
                    <p>Total Produk</p>
                </div>

                <div class="card">
                    <h1>95</h1>
                    <p>Total Customer</p>
                </div>

                <div class="card">
                    <h1>450</h1>
                    <p>Total Order</p>
                </div>

            </div>

        </div>

    </div>

</div>

</body>
</html>