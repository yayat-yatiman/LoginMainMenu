<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<title>Data Karyawan</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
.sidebar{
    width:250px;
    min-height:100vh;
    background:#212529;
}
.sidebar a{
    color:white;
    text-decoration:none;
    display:block;
    padding:12px;
}
</style>

</head>
<body>

<div class="d-flex">

    <%@include file="template/sidebar.jsp"%>

    <div class="flex-grow-1">

        <%@include file="template/header.jsp"%>

        <div class="container mt-4">

            <h3>Data Karyawan</h3>

            <button class="btn btn-primary mb-3">
                Tambah Karyawan
            </button>

            <table class="table table-bordered">

                <thead>
                    <tr>
                        <th>NIK</th>
                        <th>Nama</th>
                        <th>Jabatan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <td>12025001</td>
                        <td>Budi</td>
                        <td>Admin</td>
                        <td>
                            <button class="btn btn-warning btn-sm">Edit</button>
                            <button class="btn btn-danger btn-sm">Hapus</button>
                        </td>
                    </tr>
                </tbody>

            </table>

        </div>

    </div>

</div>

</body>
</html>