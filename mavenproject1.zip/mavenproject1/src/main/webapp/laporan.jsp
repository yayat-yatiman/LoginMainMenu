<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Laporan</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<div class="d-flex">

    <%@include file="template/sidebar.jsp"%>

    <div class="flex-grow-1">

        <%@include file="template/header.jsp"%>

        <div class="container mt-4">

            <h3>Laporan</h3>

            <div class="card">

                <div class="card-body">

                    <ul>
                        <li>Laporan Penjualan</li>
                        <li>Laporan Produk</li>
                        <li>Laporan Karyawan</li>
                    </ul>

                </div>

            </div>

        </div>

    </div>

</div>

</body>
</html>