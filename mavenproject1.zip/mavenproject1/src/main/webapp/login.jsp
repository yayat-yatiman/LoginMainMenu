<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;

            background: linear-gradient(
                135deg,
                #0f172a,
                #1e3a8a,
                #2563eb
            );
        }

        .login-container {
            width: 400px;
            background: rgba(255,255,255,0.95);
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.25);
        }

        .logo {
            text-align: center;
            margin-bottom: 25px;
        }

        .logo h2 {
            margin-top: 10px;
            color: #1e293b;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #475569;
        }

        .form-control {
            width: 100%;
            height: 45px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            padding: 10px;
            font-size: 14px;
        }

        .form-control:focus {
            outline: none;
            border-color: #2563eb;
            box-shadow: 0 0 5px rgba(37,99,235,.4);
        }

        .btn-login {
            width: 100%;
            height: 45px;
            border: none;
            border-radius: 8px;
            background: #2563eb;
            color: white;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            transition: .3s;
        }

        .btn-login:hover {
            background: #1d4ed8;
        }

        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 12px;
            color: #64748b;
        }
    </style>
</head>

<body>
    <br><br>
    <div class="login-container">

        <div class="logo">
            <!-- Jika ada logo -->
            <!-- <img src="images/logo.png" alt="Logo"> -->
            <h2>Admin Login</h2>
        </div>

        <form action="LoginServlet" method="post">

            <div class="form-group">
                <label>Username</label>
                <input type="text"
                       name="username"
                       class="form-control"
                       required>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password"
                       name="password"
                       class="form-control"
                       required>
            </div>

            <button type="submit" class="btn-login">
                Login
            </button>

        </form>

        <div class="footer">
            © 2025 Admin Panel
        </div>

    </div>

</body>
</html>