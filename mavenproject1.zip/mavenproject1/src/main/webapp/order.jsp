<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Order</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<div class="d-flex">

    <%@include file="template/sidebar.jsp"%>

    <div class="flex-grow-1">

        <%@include file="template/header.jsp"%>

        <div class="container mt-4">

            <h3>Data Order</h3>

            <table class="table table-bordered">

                <thead>
                    <tr>
                        <th>No Order</th>
                        <th>Tanggal</th>
                        <th>Total</th>
                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <td>ORD001</td>
                        <td>11-06-2026</td>
                        <td>5.000.000</td>
                    </tr>
                </tbody>

            </table>

        </div>

    </div>

</div>

</body>
</html>