<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Produk</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<div class="d-flex">

    <%@include file="template/sidebar.jsp"%>

    <div class="flex-grow-1">

        <%@include file="template/header.jsp"%>

        <div class="container mt-4">

            <h3>Master Produk</h3>

            <button class="btn btn-success mb-3">
                Tambah Produk
            </button>

            <table class="table table-striped">

                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Produk</th>
                        <th>Harga</th>
                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <td>P001</td>
                        <td>Laptop</td>
                        <td>10.000.000</td>
                    </tr>
                </tbody>

            </table>

        </div>

    </div>

</div>

</body>
</html>